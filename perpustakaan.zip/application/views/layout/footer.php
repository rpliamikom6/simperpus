<section id="top-footer">
    <div class="container">
        <div id="widget-bottom">
            <div class="row">
                <div class="col-md-3">
                    <div class="row">
                        <div class="col-md-12 widget">
                            Diselenggarakan oleh<br>
                            <b>Amikom Yogyakarta</b><br>
                            Jl. Padjajaran, Ring Road Utara, Kel. Condongcatur, Kec. Depok, Kab. Sleman, Prop. Daerah Istimewa Yogyakarta<br><br>
        
                            Email : Yayasan@amikom.ac.id
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="row">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="row">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="row">
                        <div class="col-md-12 widget">
                            Email	amikom@amikom.ac.id<br>
                            Telp	(0274) 884201 – 207<br>
                            Fax	(0274) 884208<br><br>
                            
        
                            <b>INTERNATIONAL OFFICE</b><br>
        
                            Email	io@amikom.ac.id<br>
                            Telp	+62 274884 201 Ext. 612<br>
                            Fax	+62 274884 208<br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>